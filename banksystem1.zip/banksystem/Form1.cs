﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banksystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_signbtn_Click(object sender, EventArgs e)
        {
            rigesterform rigesterform = new rigesterform();
            rigesterform.Show();
            this.Hide();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            sarting sarting = new sarting();
            sarting.Show();
            this.Hide();
        }
    }
}
