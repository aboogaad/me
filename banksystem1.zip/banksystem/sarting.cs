﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace banksystem
{
    public partial class sarting : Form
    {
        public sarting()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        int sartp = -1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            sartp+=1;
            if (sartp == 101)
                sartp = 100;
            progressBar1.Value = sartp;
            if (progressBar1.Value == 100 || sartp == 100) {
                progressBar1.Value = 0;
                timer1.Stop();
                employeemain employeemain = new employeemain();
                employeemain.Show();
                this.Hide();
            }
            
        }

        private void sarting_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
